package com.wangyiyun.dao.impl;


import com.wangyiyun.dao.ISingerDao;
import com.wangyiyun.dao.entity.Singer;
import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.utils.JdbcUtil;
import com.wangyiyun.utils.Page;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/11
 * Time: 18:51
 * To change this template use File | Settings | File Templates.
 **/


public class SingerDaoImpl implements ISingerDao {
    @Override
    public int save(Singer singer) {
        String sql = "INSERT INTO singer VALUES (?,?,?) ";
        /*if (){

        }*/
        Object[]  params = {
                singer.getSinger_id(),
                singer.getSinger_name(),
                singer.getSinger_introduction()
        };
        int rows = JdbcUtil.executeUpdate(sql, params);
        return rows;
    }

    @Override
    public int deleteById(int singer_id) {
        String sql = "DELETE FROM singer  WHERE singer_id = ? ";
        Object[] params = {singer_id};
        int row = JdbcUtil.executeUpdate(sql, params);
        return row;
    }

    @Override
    public int getCount(String condition) {
        int rows = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp WHERE ename LIKE '%s%'
        String sql = "SELECT COUNT(1) as shuliang FROM singer WHERE singer_name LIKE ?";
        try {
            ps  = conn.prepareStatement(sql);
            ps.setObject(1, "%"+condition+"%");
            rs = ps.executeQuery();
            if (rs.next()) {
                //rows = rs.getInt(1);
                rows = rs.getInt("shuliang");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, ps, conn);
        }

        return rows;
    }

    @Override
    public List<Singer> listOnePageInfo(String condition, int currentPage, int pageSize) {
        List<Singer> list  =  new ArrayList<Singer>();
        PreparedStatement pst = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        int s = 0;
        String sql = "SELECT * FROM singer WHERE singer_name LIKE ? LIMIT ?,? ";
        try {
            s = (currentPage-1)*pageSize;
            pst  = conn.prepareStatement(sql);
            pst.setObject(1, "%"+condition+"%");
            pst.setObject(2, s);
            pst.setObject(3, pageSize);
            rs = pst.executeQuery();
            while (rs.next()) {
                Singer singer = new Singer();
                singer.setSinger_id(rs.getInt("singer_id"));
                singer.setSinger_name(rs.getString("singer_name"));
                singer.setSinger_introduction(rs.getString("singer_introduction"));
                list.add(singer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, pst, conn);
        }
        return list;
    }

    @Override
    public Page<Singer> getPage(String condition, int currentPage, int pageSize) {
        int count = this.getCount(condition);
        List<Singer> list = this.listOnePageInfo(condition, currentPage, pageSize);
        Page<Singer> page = new Page<Singer>(currentPage, pageSize, count, list);
        return page;
    }


    @Override
    public int update(Singer singer) {
            //不修改图片的情况
            //UPDATE emp SET ename='hh',job='hh',mgr=8765,hiredate='1898-09-08' ,sal=8765 ,comm=76,deptno=20,picture_path='xxx.jpg',lastOperatorTime='2019-09-08' WHERE empno=9494
            String sql = " UPDATE singer SET singer_name=?,singer_introduction=? WHERE singer_id=? ";
            Object[]  params = {
                    singer.getSinger_name(),
                    singer.getSinger_introduction(),
                    singer.getSinger_id()

            };
            int rows = JdbcUtil.executeUpdate(sql, params);
            return rows;
    }

    @Override
    public Singer getSingerById(int singer_id) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp
        String sql = "SELECT * FROM singer WHERE singer_id = ? ";
        Singer singer = new Singer();
        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1, singer_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                singer.setSinger_id(rs.getInt("singer_id"));
                singer.setSinger_name(rs.getString("singer_name"));
                singer.setSinger_introduction(rs.getString("singer_introduction"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.closeAll(rs, ps, conn);
        }
        return singer;
    }

    @Override
    public Singer getSingerByName(String singer_name) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp
        String sql = "SELECT * FROM singer WHERE singer_name = ? ";
        Singer singer = new Singer();
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, singer_name);
            rs = ps.executeQuery();
            if (rs.next()) {
                singer.setSinger_id(rs.getInt("singer_id"));
                singer.setSinger_name(rs.getString("singer_name"));
                singer.setSinger_introduction(rs.getString("singer_introduction"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.closeAll(rs, ps, conn);
        }
        return singer;
    }

    @Override
    public List<Singer> getSingerAll() {
        List<Singer> singers = new ArrayList<Singer>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp
        String sql = " SELECT * FROM singer";
        try {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Singer singer = new Singer();
                singer.setSinger_id(rs.getInt("singer_id"));
                singer.setSinger_name(rs.getString("singer_name"));
                singer.setSinger_introduction(rs.getString("singer_introduction"));
                singers.add(singer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.closeAll(rs, ps, conn);
        }
        return singers;
    }
}
