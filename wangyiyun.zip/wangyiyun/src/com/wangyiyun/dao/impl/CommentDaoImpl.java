package com.wangyiyun.dao.impl;

import com.wangyiyun.dao.ICommentDao;
import com.wangyiyun.dao.entity.Comment;
import com.wangyiyun.dao.entity.User;
import com.wangyiyun.service.ISingerService;
import com.wangyiyun.service.IUserService;
import com.wangyiyun.service.impl.SingerServiceImpl;
import com.wangyiyun.service.impl.UserServiceImpl;
import com.wangyiyun.utils.JdbcUtil;
import com.wangyiyun.utils.Page;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/14
 * Time: 15:58
 * To change this template use File | Settings | File Templates.
 **/


public class CommentDaoImpl implements ICommentDao {
    ISingerService singerService = new SingerServiceImpl();
    @Override
    public int deleteById(int comment_id) {
        String sql = "DELETE FROM comment  WHERE comment_id = ? ";
        Object[] params = {comment_id};
        int row = JdbcUtil.executeUpdate(sql, params);
        return row;
    }

    @Override
    public int getCount(String condition) {
        int rows = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp WHERE ename LIKE '%s%'
        String sql = "SELECT COUNT(1) as shuliang FROM comment WHERE comment_content LIKE ?";
        try {
            ps  = conn.prepareStatement(sql);
            ps.setObject(1, "%"+condition+"%");
            rs = ps.executeQuery();
            if (rs.next()) {
                //rows = rs.getInt(1);
                rows = rs.getInt("shuliang");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, ps, conn);
        }

        return rows;
    }

    @Override
    public List<Comment> listOnePageInfo(String condition, int currentPage, int pageSize) {
        List<Comment> list  =  new ArrayList<Comment>();
        PreparedStatement pst = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        int s = 0;
        String sql = "SELECT * FROM comment WHERE comment_content LIKE ? LIMIT ?,? ";
        try {
            s = (currentPage-1)*pageSize;
            pst  = conn.prepareStatement(sql);
            pst.setObject(1, "%"+condition+"%");
            pst.setObject(2, s);
            pst.setObject(3, pageSize);
            rs = pst.executeQuery();
            while (rs.next()) {
                Comment comment = new Comment();
                comment.setCommentId(rs.getInt("comment_id"));
                comment.setCommentDate(rs.getDate("comment_date"));
                comment.setCommentContent(rs.getString("comment_content"));
                comment.setContentDzs(rs.getInt("content_dzs"));  //点赞数
                comment.setContentSongId(rs.getInt("content_song_id")); //歌曲
                comment.setContentSongsId(rs.getInt("content_songs_id"));  //歌单
                comment.setContentFid(rs.getInt("content_fid"));
                comment.setContentUserId(rs.getInt("content_user_id"));
                list.add(comment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, pst, conn);
        }
        return list;
    }

    @Override
    public Comment getById(int comment_id) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp
        String sql = "SELECT * FROM comment WHERE comment_id = ? ";
        Comment comment = new Comment();
        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1, comment_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                comment.setCommentId(rs.getInt("comment_id"));
                comment.setCommentDate(rs.getDate("comment_date"));
                comment.setCommentContent(rs.getString("comment_content"));
                comment.setContentDzs(rs.getInt("content_dzs"));
                comment.setContentSongId(rs.getInt("content_song_id"));
                comment.setContentSongsId(rs.getInt("content_songs_id"));
                comment.setContentFid(rs.getInt("content_fid"));
                comment.setContentUserId(rs.getInt("content_user_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.closeAll(rs, ps, conn);
        }
        return comment;
    }

    @Override
    public List<Comment> getCommentAll() {
        List<Comment> comments = new ArrayList<Comment>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp
        String sql = " SELECT * FROM comment";
        try {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Comment comment = new Comment();
                comment.setCommentId(rs.getInt("comment_id"));
                comment.setCommentDate(rs.getDate("comment_date"));
                comment.setCommentContent(rs.getString("comment_content"));
                comment.setContentDzs(rs.getInt("content_dzs"));
                comment.setContentSongId(rs.getInt("content_song_id"));
                comment.setContentSongsId(rs.getInt("content_songs_id"));
                comment.setContentFid(rs.getInt("content_fid"));
                comment.setContentUserId(rs.getInt("content_user_id"));
                comments.add(comment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.closeAll(rs, ps, conn);
        }
        return comments;

    }

    @Override
    public Page<Comment> getPage(String condition, int currentPage, int pageSize) {
        int count = this.getCount(condition);
        List<Comment> list = this.listOnePageInfo(condition, currentPage, pageSize);
        Page<Comment> page = new Page<Comment>(currentPage, pageSize, count, list);
        return page;
    }


}
