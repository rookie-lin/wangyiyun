package com.wangyiyun.dao.impl;

import com.wangyiyun.dao.IUserDao;
import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.dao.entity.User;
import com.wangyiyun.utils.JdbcUtil;
import com.wangyiyun.utils.Page;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/14
 * Time: 9:54
 * To change this template use File | Settings | File Templates.
 **/


public class UserDaoImpl implements IUserDao {
    @Override
    public int save(User user) {
            /*String sql = "INSERT INTO song(song_name,song_singer,song_time,song_picture,song_path,song_ablum) VALUES (?,?,?,?,?,?) ";*/
            String sql = "INSERT INTO user(user_name,password,head_portrait_path,address,sex,introducetion,birthday) VALUES (?,?,?,?,?,?,?)";
            Object[]  params = {
                   user.getUserName(),user.getPassword(),user.getHeadPortraitPath(),
                    user.getAddress(),user.getSex(),user.getIntroducetion(),user.getBirthday()
            };
            int rows = JdbcUtil.executeUpdate(sql, params);
            return rows;
    }

    @Override
    public int deleteById(int user_id) {
        String sql = "DELETE FROM user  WHERE user_id = ? ";
        Object[] params = {user_id};
        int row = JdbcUtil.executeUpdate(sql, params);
        return row;

    }

    @Override
    public List<User> listAll() {
        List<User> list  =  new ArrayList<User>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        String sql = " SELECT * FROM user ";
        Map<String,Object> map = new HashMap<String,Object>();
        try {
            ps  = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setUserName(rs.getString("user_name"));
                user.setPassword(rs.getString("password"));
                user.setHeadPortraitPath(rs.getString("head_portrait_path"));
                user.setAddress(rs.getString("address"));
                user.setSex(rs.getString("sex"));
                user.setIntroducetion(rs.getString("introducetion"));
                user.setBirthday(rs.getDate("birthday"));
                list.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, ps, conn);
        }
        return list;
    }

    @Override
    public int update(User user) {
        //不修改图片的情况下
            if (user.getHeadPortraitPath()==null){
                // String sql = "INSERT INTO user(user_name,password,head_portrait_path,address,sex,introducetion,birthday) VALUES (?,?,?,?,?,?,?)";
                String sql = " UPDATE user SET user_name=?,password=?,address=?,sex=? ,introducetion=?,birthday=? WHERE user_id=? ";
                Object[]  params = {
                        user.getUserName(),user.getPassword(),
                        user.getAddress(),user.getSex(),user.getIntroducetion(),user.getBirthday(),
                        user.getUserId()
                };
                int rows = JdbcUtil.executeUpdate(sql, params);
                return rows;
            }else {
                //修改图片的情况
                // String sql = "INSERT INTO user(user_name,password,head_portrait_path,address,sex,introducetion,birthday) VALUES (?,?,?,?,?,?,?)";
                String sql = " UPDATE user SET user_name=?,password=?,head_portrait_path=?,address=?,sex=? ,introducetion=?,birthday=? WHERE user_id=? ";
                Object[]  params = {
                        user.getUserName(),user.getPassword(),user.getHeadPortraitPath(),
                        user.getAddress(),user.getSex(),user.getIntroducetion(),user.getBirthday(),
                        user.getUserId()

                };
                int rows = JdbcUtil.executeUpdate(sql, params);
                return rows;
            }


    }

    @Override
    public int getCount(String condition) {
        int rows = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp WHERE ename LIKE '%s%'
        String sql = "SELECT COUNT(1) as shuliang FROM user WHERE user_name LIKE ?";
        try {
            ps  = conn.prepareStatement(sql);
            ps.setObject(1, "%"+condition+"%");
            rs = ps.executeQuery();
            if (rs.next()) {
                //rows = rs.getInt(1);
                rows = rs.getInt("shuliang");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, ps, conn);
        }

        return rows;
    }

    @Override
    public List<User> listOnePageInfo(String condition, int currentPage, int pageSize) {
        List<User> list  =  new ArrayList<User>();
        PreparedStatement pst = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        int s = 0;
        String sql = "SELECT * FROM user WHERE user_name LIKE ? LIMIT ?,? ";
        try {
            s = (currentPage-1)*pageSize;
            pst  = conn.prepareStatement(sql);
            pst.setObject(1, "%"+condition+"%");
            pst.setObject(2, s);
            pst.setObject(3, pageSize);
            rs = pst.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setUserName(rs.getString("user_name"));
                user.setPassword(rs.getString("password"));
                user.setHeadPortraitPath(rs.getString("head_portrait_path"));
                user.setAddress(rs.getString("address"));
                user.setSex(rs.getString("sex"));
                user.setIntroducetion(rs.getString("introducetion"));
                user.setBirthday(rs.getDate("birthday"));
                list.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, pst, conn);
        }
        return list;
    }

    @Override
    public Page<User> getPage(String condition, int currentPage, int pageSize) {
        int count = this.getCount(condition);
        List<User> list = this.listOnePageInfo(condition, currentPage, pageSize);
        Page<User> page = new Page<User>(currentPage, pageSize, count, list);
        return page;
    }

    @Override
    public User getById(int user_id) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp
        String sql = "SELECT * FROM user WHERE user_id = ? ";
        User user = new User();
        try {
            ps  = conn.prepareStatement(sql);
            ps.setInt(1, user_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                user.setUserId(rs.getInt("user_id"));
                user.setUserName(rs.getString("user_name"));
                user.setPassword(rs.getString("password"));
                user.setHeadPortraitPath(rs.getString("head_portrait_path"));
                user.setAddress(rs.getString("address"));
                user.setSex(rs.getString("sex"));
                user.setIntroducetion(rs.getString("introducetion"));
                user.setBirthday(rs.getDate("birthday"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, ps, conn);
        }
        return user;
    }
}
