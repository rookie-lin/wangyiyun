package com.wangyiyun.dao.impl;

import com.wangyiyun.dao.ISongDao;
import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.utils.JdbcUtil;
import com.wangyiyun.utils.Page;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/10
 * Time: 17:06
 * To change this template use File | Settings | File Templates.
 **/


public class SonDaoImpl implements ISongDao {
    @Override
    public int save(Song song) {
        //INSERT INTO emp VALUES (3453,'lily','manager','7839','1987-09-08',7655,87,20)Song song
        if (0==song.getSong_Plays() && 0==song.getSong_Collect() && 0==song.getSong_Forward()){
            /*String sql = "INSERT INTO song(song_name,song_singer,song_time,song_picture,song_path,song_ablum) VALUES (?,?,?,?,?,?) ";*/
            String sql = "INSERT INTO song(song_name,song_picture,song_time,song_singer,song_album,song_path) VALUES (?,?,?,?,?,?)";
            Object[]  params = {song.getSong_Name(),song.getSong_Picture(),song.getSong_Time(),song.getSong_Singer(),song.getSong_Album() ,song.getSong_Path()
                   };
            int rows = JdbcUtil.executeUpdate(sql, params);
            return rows;
        }else {
            String sql = "INSERT INTO song VALUES (?,?,?,?,?,?,?,?,?) ";
            Object[]  params = {song.getSong_Name(),song.getSong_Picture(),
                    song.getSong_Time(),song.getSong_Singer(),song.getSong_Album(),song.getSong_Plays(),
                    song.getSong_Collect(),song.getSong_Forward(),song.getSong_Path() };
            int rows = JdbcUtil.executeUpdate(sql, params);
            return rows;
        }
    }
    //得到分页的总记录数
    @Override
    public int getCount(String condition) {

        int rows = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp WHERE ename LIKE '%s%'
        String sql = "SELECT COUNT(1) as shuliang FROM song WHERE song_name LIKE ?";
        try {
            ps  = conn.prepareStatement(sql);
            ps.setObject(1, "%"+condition+"%");
            rs = ps.executeQuery();
            if (rs.next()) {
                //rows = rs.getInt(1);
                rows = rs.getInt("shuliang");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, ps, conn);
        }

        return rows;
    }
    //得到一页中的详细信息
    public List<Song> listOnePageInfo(String condition, int currentPage,int pageSize) {

        List<Song> list  =  new ArrayList<Song>();
        PreparedStatement pst = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        int s = 0;
        String sql = "SELECT * FROM song WHERE song_name LIKE ? LIMIT ?,? ";
        try {
            s = (currentPage-1)*pageSize;
            pst  = conn.prepareStatement(sql);
            pst.setObject(1, "%"+condition+"%");
            pst.setObject(2, s);
            pst.setObject(3, pageSize);
            rs = pst.executeQuery();
            while (rs.next()) {
                Song song = new Song();
                song.setSong_Id(rs.getInt("song_id"));
                song.setSong_Name(rs.getString("song_name"));
                song.setSong_Picture(rs.getString("song_picture"));
                song.setSong_Time(rs.getString("song_time"));
                song.setSong_Singer(rs.getInt("song_singer"));
                song.setSong_Album(rs.getString("song_album"));
                song.setSong_Plays(rs.getLong("song_plays"));
                song.setSong_Collect(rs.getLong("song_collect"));
                song.setSong_Forward(rs.getLong("song_forward"));
                list.add(song);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, pst, conn);
        }
        return list;
    }

    @Override
    public Page<Song> getPage(String condition, int currentPage, int pageSize) {
        int count = this.getCount(condition);
        List<Song> list = this.listOnePageInfo(condition, currentPage, pageSize);
        Page<Song> page = new Page<Song>(currentPage, pageSize, count, list);
        return page;
    }

    @Override
    public Song getById(int song_id) {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        //SELECT COUNT(1) FROM emp
        String sql = "SELECT * FROM song WHERE song_id = ? ";
        Song song = new Song();
        try {
            ps  = conn.prepareStatement(sql);
            ps.setInt(1, song_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                song.setSong_Id(rs.getInt("song_id"));
                song.setSong_Name(rs.getString("song_name"));
                song.setSong_Picture(rs.getString("song_picture"));
                song.setSong_Time(rs.getString("song_time"));
                song.setSong_Singer(rs.getInt("song_singer"));
                song.setSong_Album(rs.getString("song_album"));
                song.setSong_Path(rs.getString("song_path"));
                song.setSong_Plays(rs.getLong("song_plays"));
                song.setSong_Collect(rs.getLong("song_collect"));
                song.setSong_Forward(rs.getLong("song_forward"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, ps, conn);
        }
        return song;
    }
 /*   //得到一页中的全部信息
    @Override
    public Page<Employee> getPage(String condition, int currentPage,int pageSize) {
        int count = this.getCount(condition);
        List<Employee> list = this.listOnePageInfo(condition, currentPage, pageSize) ;
        Page0<Employee> page = new Page<Employee>(currentPage, pageSize, count, list);
        return page;
    }*/


    //根据歌名删除一首歌信息
    public int deleteById(int song_id){
        String sql = "DELETE FROM song  WHERE song_id = ? ";
        Object[] params = {song_id};
        int row = JdbcUtil.executeUpdate(sql, params);
        return row;
    }

    //修改歌曲
    public int update(Song song) {
        if (song.getSong_Picture() == null) {
            //不修改图片的情况
            //UPDATE emp SET ename='hh',job='hh',mgr=8765,hiredate='1898-09-08' ,sal=8765 ,comm=76,deptno=20,picture_path='xxx.jpg',lastOperatorTime='2019-09-08' WHERE empno=9494
            String sql = " UPDATE song SET song_name=?,song_singer=?,song_time=?,song_path=?,song_album=? WHERE song_id=? ";
            Object[]  params = {
                    song.getSong_Name(),
                    song.getSong_Singer(),
                    song.getSong_Time(),
                    song.getSong_Path(),
                    song.getSong_Album(),
                    song.getSong_Id()

            };
            int rows = JdbcUtil.executeUpdate(sql, params);
            return rows;
        }
        else if (song.getSong_Path() == null && song.getSong_Picture() == null) {
            //不修改歌曲的情况
            //UPDATE emp SET ename='hh',job='hh',mgr=8765,hiredate='1898-09-08' ,sal=8765 ,comm=76,deptno=20,picture_path='xxx.jpg',lastOperatorTime='2019-09-08' WHERE empno=9494
            String sql = " UPDATE song SET song_name=?,song_singer=?,song_time=?,song_album=? WHERE song_id=? ";
            Object[]  params = {
                    song.getSong_Name(),
                    song.getSong_Singer(),
                    song.getSong_Time(),
                    song.getSong_Album(),
                    song.getSong_Id()

            };
            int rows = JdbcUtil.executeUpdate(sql, params);
            return rows;
        }
        else if (song.getSong_Path() == null) {
            //不修改图片的情况
            //UPDATE emp SET ename='hh',job='hh',mgr=8765,hiredate='1898-09-08' ,sal=8765 ,comm=76,deptno=20,picture_path='xxx.jpg',lastOperatorTime='2019-09-08' WHERE empno=9494
            String sql = " UPDATE song SET song_name=?,song_singer=?,song_time=?,song_picture=?,song_album=? WHERE song_id=? ";
            Object[]  params = {
                    song.getSong_Name(),
                    song.getSong_Singer(),
                    song.getSong_Time(),
                    song.getSong_Picture(),
                    song.getSong_Album(),
                    song.getSong_Id()

            };
            int rows = JdbcUtil.executeUpdate(sql, params);
            return rows;
        }
        else {
            //修改图片的情况
            //UPDATE emp SET ename='hh',job='hh',mgr=8765,hiredate='1898-09-08' ,sal=8765 ,comm=76,deptno=20,picture_path='xxx.jpg',lastOperatorTime='2019-09-08' WHERE empno=9494
            String sql = " UPDATE song SET song_name=?,song_singer=?,song_time=?,song_album=?,song_picture=? ,song_path=? WHERE song_id=? ";
            Object[]  params = {
                    song.getSong_Name(),
                    song.getSong_Singer(),
                    song.getSong_Time(),
                    song.getSong_Album(),
                    song.getSong_Picture(),
                    song.getSong_Path(),
                    song.getSong_Id()
            };
            int rows = JdbcUtil.executeUpdate(sql, params);
            return rows;
        }


    }

    //查询全部歌曲
    public List<Song> listAll() {
        List<Song> list  =  new ArrayList<Song>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = JdbcUtil.getConnection();
        String sql = " SELECT * FROM song ";
        Map<String,Object> map = new HashMap<String,Object>();
        try {
            ps  = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Song song = new Song();
                song.setSong_Id(rs.getInt("song_id"));

                song.setSong_Name(rs.getString("song_name"));
                song.setSong_Picture(rs.getString("song_picture"));
                song.setSong_Time(rs.getString("song_time"));
                song.setSong_Singer(rs.getInt("song_singer"));
                song.setSong_Album(rs.getString("song_album"));
                song.setSong_Plays(rs.getLong("song_plays"));
                song.setSong_Collect(rs.getLong("song_collect"));
                song.setSong_Forward(rs.getLong("song_forward"));
                list.add(song);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            JdbcUtil.closeAll(rs, ps, conn);
        }
        return list;
    }
}
