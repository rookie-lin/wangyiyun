package com.wangyiyun.dao.entity;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/11
 * Time: 18:46
 * To change this template use File | Settings | File Templates.
 **/


public class Singer {
    private int singer_id;
    private String singer_name;
    private String singer_introduction;

    public int getSinger_id() {
        return singer_id;
    }

    public void setSinger_id(int singer_id) {
        this.singer_id = singer_id;
    }

    public String getSinger_name() {
        return singer_name;
    }

    public void setSinger_name(String singer_name) {
        this.singer_name = singer_name;
    }

    public String getSinger_introduction() {
        return singer_introduction;
    }

    public void setSinger_introduction(String singer_introduction) {
        this.singer_introduction = singer_introduction;
    }

    public Singer() {
        super();
    }

    public Singer(int singer_id, String singer_name, String singer_introduction) {
        this.singer_id = singer_id;
        this.singer_name = singer_name;
        this.singer_introduction = singer_introduction;
    }
}
