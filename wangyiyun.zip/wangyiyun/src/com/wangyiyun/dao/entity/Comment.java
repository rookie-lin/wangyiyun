package com.wangyiyun.dao.entity;


import java.sql.Date;

public class Comment {

  private long commentId;
  private java.sql.Date commentDate;
  private String commentContent;
  private long contentFid;
  private long contentDzs;
  private long contentSongId;
  private long contentSongsId;
  private long contentUserId;


  public long getCommentId() {
    return commentId;
  }

  public void setCommentId(long commentId) {
    this.commentId = commentId;
  }


  public java.sql.Date getCommentDate() {
    return commentDate;
  }

  public void setCommentDate(java.sql.Date commentDate) {
    this.commentDate = commentDate;
  }


  public String getCommentContent() {
    return commentContent;
  }

  public void setCommentContent(String commentContent) {
    this.commentContent = commentContent;
  }


  public long getContentFid() {
    return contentFid;
  }

  public void setContentFid(long contentFid) {
    this.contentFid = contentFid;
  }


  public long getContentDzs() {
    return contentDzs;
  }

  public void setContentDzs(long contentDzs) {
    this.contentDzs = contentDzs;
  }


  public long getContentSongId() {
    return contentSongId;
  }

  public void setContentSongId(long contentSongId) {
    this.contentSongId = contentSongId;
  }


  public long getContentSongsId() {
    return contentSongsId;
  }

  public void setContentSongsId(long contentSongsId) {
    this.contentSongsId = contentSongsId;
  }


  public long getContentUserId() {
    return contentUserId;
  }

  public void setContentUserId(long contentUserId) {
    this.contentUserId = contentUserId;
  }

  public Comment() {
    super();
  }

  public Comment(long commentId, Date commentDate, String commentContent, long contentFid, long contentDzs, long contentSongId, long contentSongsId, long contentUserId) {
    this.commentId = commentId;
    this.commentDate = commentDate;
    this.commentContent = commentContent;
    this.contentFid = contentFid;
    this.contentDzs = contentDzs;
    this.contentSongId = contentSongId;
    this.contentSongsId = contentSongsId;
    this.contentUserId = contentUserId;
  }
}
