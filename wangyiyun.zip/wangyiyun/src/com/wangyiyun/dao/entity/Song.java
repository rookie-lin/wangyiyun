package com.wangyiyun.dao.entity;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/10
 * Time: 16:10
 * To change this template use File | Settings | File Templates.
 **/


public class Song {
    private int song_Id;
    private String song_Name;
    private String song_Picture;
    private String song_Time;
    private int song_Singer;
    private String song_Album;
    private long song_Plays;
    private long song_Collect;
    private long song_Forward;
    private String song_Path;

    public String getSong_Path() {
        return song_Path;
    }

    public void setSong_Path(String song_Path) {
        this.song_Path = song_Path;
    }

    public int getSong_Id() {
        return song_Id;
    }

    public void setSong_Id(int song_Id) {
        this.song_Id = song_Id;
    }

    public String getSong_Name() {
        return song_Name;
    }

    public void setSong_Name(String song_Name) {
        this.song_Name = song_Name;
    }

    public String getSong_Picture() {
        return song_Picture;
    }

    public void setSong_Picture(String song_Picture) {
        this.song_Picture = song_Picture;
    }

    public String getSong_Time() {
        return song_Time;
    }

    public void setSong_Time(String song_Time) {
        this.song_Time = song_Time;
    }

    public int getSong_Singer() {
        return song_Singer;
    }

    public void setSong_Singer(int song_Singer) {
        this.song_Singer = song_Singer;
    }

    public String getSong_Album() {
        return song_Album;
    }

    public void setSong_Album(String song_Album) {
        this.song_Album = song_Album;
    }

    public long getSong_Plays() {
        return song_Plays;
    }

    public void setSong_Plays(long song_Plays) {
        this.song_Plays = song_Plays;
    }

    public long getSong_Collect() {
        return song_Collect;
    }

    public void setSong_Collect(long song_Collect) {
        this.song_Collect = song_Collect;
    }

    public long getSong_Forward() {
        return song_Forward;
    }

    public void setSong_Forward(long song_Forward) {
        this.song_Forward = song_Forward;
    }

    public Song() {
        super();
    }

    public Song(int song_Id, String song_Name, String song_Picture, String song_Time, int song_Singer, String song_Album, long song_Plays, long song_Collect, long song_Forward, String song_Path) {
        this.song_Id = song_Id;
        this.song_Name = song_Name;
        this.song_Picture = song_Picture;
        this.song_Time = song_Time;
        this.song_Singer = song_Singer;
        this.song_Album = song_Album;
        this.song_Plays = song_Plays;
        this.song_Collect = song_Collect;
        this.song_Forward = song_Forward;
        this.song_Path = song_Path;
    }

    @Override
    public String toString() {
        return "Song{" +
                "song_Id=" + song_Id +
                ", song_Name='" + song_Name + '\'' +
                ", song_Picture='" + song_Picture + '\'' +
                ", song_Time='" + song_Time + '\'' +
                ", song_Singer=" + song_Singer +
                ", song_Album='" + song_Album + '\'' +
                ", song_Plays=" + song_Plays +
                ", song_Collect=" + song_Collect +
                ", song_Forward=" + song_Forward +
                ", song_Path='" + song_Path + '\'' +
                '}';
    }
}
