package com.wangyiyun.dao.entity;

import java.sql.Date;

public class User {

  private long userId;
  private String userName;
  private String password;
  private String headPortraitPath;
  private String address;
  private String sex;
  private String introducetion;
  private java.sql.Date birthday;


  public long getUserId() {
    return userId;
  }

  public void setUserId(long userId) {
    this.userId = userId;
  }


  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }


  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }


  public String getHeadPortraitPath() {
    return headPortraitPath;
  }

  public void setHeadPortraitPath(String headPortraitPath) {
    this.headPortraitPath = headPortraitPath;
  }


  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }


  public String getSex() {
    return sex;
  }

  public void setSex(String sex) {
    this.sex = sex;
  }


  public String getIntroducetion() {
    return introducetion;
  }

  public void setIntroducetion(String introducetion) {
    this.introducetion = introducetion;
  }


  public java.sql.Date getBirthday() {
    return birthday;
  }

  public void setBirthday(java.sql.Date birthday) {
    this.birthday = birthday;
  }

  public User() {
  }

  public User(long userId, String userName, String password, String headPortraitPath, String address, String sex, String introducetion, Date birthday) {
    this.userId = userId;
    this.userName = userName;
    this.password = password;
    this.headPortraitPath = headPortraitPath;
    this.address = address;
    this.sex = sex;
    this.introducetion = introducetion;
    this.birthday = birthday;
  }
}
