package com.wangyiyun.dao;

import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/10
 * Time: 16:54
 * To change this template use File | Settings | File Templates.
 **/


public interface ISongDao {

    public int save(Song song);

    public int deleteById(int song_id);

    public List<Song> listAll();

    public int update(Song song);

    public int getCount(String condition);

    public List<Song> listOnePageInfo(String condition, int currentPage, int pageSize);

    Page<Song> getPage(String condition, int currentPage, int pageSize);

    public Song getById(int song_id);

}
