package com.wangyiyun.dao;

import com.wangyiyun.dao.entity.Comment;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/14
 * Time: 15:53
 * To change this template use File | Settings | File Templates.
 **/


public interface ICommentDao {

    public int deleteById(int comment_id);

    public int getCount(String condition);

    public List<Comment> listOnePageInfo(String condition, int currentPage, int pageSize);

    Page<Comment> getPage(String condition, int currentPage, int pageSize);

    public Comment getById(int comment_id);

    public List<Comment> getCommentAll();

}
