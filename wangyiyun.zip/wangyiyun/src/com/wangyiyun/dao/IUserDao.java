package com.wangyiyun.dao;

import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.dao.entity.User;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/14
 * Time: 9:48
 * To change this template use File | Settings | File Templates.
 **/


public interface IUserDao {

    public int save(User user);

    public int deleteById(int user_id);

    public List<User> listAll();

    public int update(User user);

    public int getCount(String condition);

    public List<User> listOnePageInfo(String condition, int currentPage, int pageSize);

    Page<User> getPage(String condition, int currentPage, int pageSize);

    public User getById(int user_id);
}
