package com.wangyiyun.utils;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Properties;


public class JdbcUtil {
	
	private static Connection conn = null;
	static{
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	//得到数据库连接
	public static Connection  getConnection() {
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/wangyiyun","root","123456" );
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return conn;
	}
	
	/**
	 *  方法说明：通用的增删改方法
	 *    使用方法：你可以传人增删改的sql与，和相对应的数组，里面放数据跟占位符顺序一致。
	 *    举例：sql  ：    INSERT INTO t_admin (adm_id,ADM_USERNAME,ADM_PASSWORD) VALUES (?,?,?);
	 *    Object[] params = {3,“王五”,"7889"};
	 * @param
	 * @return
	 */
	public static int executeUpdate(String sql, Object[] params) {
		int rows = -1;
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = JdbcUtil.getConnection();
			//String sql = "INSERT INTO t_admin (adm_id,ADM_USERNAME,ADM_PASSWORD) VALUES (?,?,?);";
			ps = conn.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
				ps.setObject(i+1, params[i]);
			}
			rows = ps.executeUpdate();//不传sql语句
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.closeAll(null, ps, conn);
		}
		return rows;
	}
	
	
	public static void closeAll(ResultSet rs,Statement state, Connection conn) {
		try {
			// 3.5关闭资源。最后开的，最先关
			if (rs!=null) {
				rs.close();
			}
			if (state != null) {
				state.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}

