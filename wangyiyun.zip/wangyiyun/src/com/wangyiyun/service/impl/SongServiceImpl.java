package com.wangyiyun.service.impl;

import com.wangyiyun.dao.ISongDao;
import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.dao.impl.SonDaoImpl;
import com.wangyiyun.service.ISongService;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/10
 * Time: 21:05
 * To change this template use File | Settings | File Templates.
 **/


public class SongServiceImpl implements ISongService {
    ISongDao songDao = new SonDaoImpl();
    @Override
    public int save(Song song) {
        return songDao.save(song);
    }

    @Override
    public boolean deleteById(int song_id) {
        int i = songDao.deleteById(song_id);
        boolean flag = false;
        if (i>0){
            flag = true;
        }
        return flag;
    }

    @Override
    public List<Song> listAll() {
        return songDao.listAll();
    }

    @Override
    public int update(Song song) {
        return songDao.update(song);
    }

    @Override
    public int getCount(String condition) {
        return songDao.getCount(condition);
    }

    @Override
    public Page<Song> getPage(String condition, int currentPage, int pageSize) {
        return songDao.getPage(condition,currentPage,pageSize);
    }


    @Override
    public Song getById(int song_id) {
        return  songDao.getById(song_id);
    }
}
