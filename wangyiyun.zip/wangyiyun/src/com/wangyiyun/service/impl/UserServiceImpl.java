package com.wangyiyun.service.impl;

import com.wangyiyun.dao.IUserDao;
import com.wangyiyun.dao.entity.User;
import com.wangyiyun.dao.impl.UserDaoImpl;
import com.wangyiyun.service.IUserService;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/14
 * Time: 10:25
 * To change this template use File | Settings | File Templates.
 **/


public class UserServiceImpl implements IUserService {
    IUserDao userDao = new UserDaoImpl();
    @Override
    public int save(User user) {
        return userDao.save(user);
    }

    @Override
    public boolean deleteById(int user_id) {
        boolean flag = false;
        if (userDao.deleteById(user_id)>0){
            flag=true;
        }
        return flag;
    }

    @Override
    public List<User> listAll() {
        return userDao.listAll();
    }

    @Override
    public int update(User user) {
        return userDao.update(user);
    }

    @Override
    public int getCount(String condition) {
        return userDao.getCount(condition);
    }

    @Override
    public Page<User> getPage(String condition, int currentPage, int pageSize) {
        return userDao.getPage(condition,currentPage,pageSize);
    }


    @Override
    public User getById(int user_id) {
        return userDao.getById(user_id);
    }
}
