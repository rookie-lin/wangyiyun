package com.wangyiyun.service.impl;

import com.wangyiyun.dao.ISingerDao;
import com.wangyiyun.dao.entity.Singer;
import com.wangyiyun.dao.impl.SingerDaoImpl;
import com.wangyiyun.service.ISingerService;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/15
 * Time: 13:04
 * To change this template use File | Settings | File Templates.
 **/


public class SingerServiceImpl implements ISingerService {
    ISingerDao singerDao = new SingerDaoImpl();
    @Override
    public int save(Singer singer) {
        return singerDao.save(singer);
    }

    @Override
    public int deleteById(int song_id) {
        return singerDao.deleteById(song_id);
    }

    @Override
    public int getCount(String condition) {
        return singerDao.getCount(condition);
    }

    @Override
    public List<Singer> listOnePageInfo(String condition, int currentPage, int pageSize) {
        return singerDao.listOnePageInfo(condition,currentPage,pageSize);
    }

    @Override
    public Page<Singer> getPage(String condition, int currentPage, int pageSize) {
        return singerDao.getPage(condition,currentPage,pageSize);
    }

    @Override
    public int update(Singer singer) {
        return singerDao.update(singer);
    }

    @Override
    public Singer getSingerById(int singer_id) {
        return singerDao.getSingerById(singer_id);
    }

    @Override
    public Singer getSingerByName(String singer_name) {
        return singerDao.getSingerByName(singer_name);
    }

    @Override
    public List<Singer> getSingerAll() {
        return singerDao.getSingerAll();
    }
}
