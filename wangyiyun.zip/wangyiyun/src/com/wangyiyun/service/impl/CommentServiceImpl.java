package com.wangyiyun.service.impl;

import com.wangyiyun.dao.ICommentDao;
import com.wangyiyun.dao.entity.Comment;
import com.wangyiyun.dao.impl.CommentDaoImpl;
import com.wangyiyun.service.ICommentService;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/14
 * Time: 16:28
 * To change this template use File | Settings | File Templates.
 **/


public class CommentServiceImpl implements ICommentService {
    ICommentDao commentDao = new CommentDaoImpl();
    @Override
    public int deleteById(int comment_id) {
        return commentDao.deleteById(comment_id);
    }

    @Override
    public int getCount(String condition) {
        return commentDao.getCount(condition);
    }

    @Override
    public Page<Comment> getPage(String condition, int currentPage, int pageSize) {
        return commentDao.getPage(condition,currentPage,pageSize);
    }

    @Override
    public Comment getById(int comment_id) {
        return commentDao.getById(comment_id);
    }

    @Override
    public List<Comment> getCommentAll() {
        return commentDao.getCommentAll();
    }
}
