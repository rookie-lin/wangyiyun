package com.wangyiyun.service;

import com.wangyiyun.dao.entity.Comment;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/14
 * Time: 16:28
 * To change this template use File | Settings | File Templates.
 **/


public interface ICommentService {
    public int deleteById(int comment_id);

    public int getCount(String condition);

    Page<Comment> getPage(String condition, int currentPage, int pageSize);

    public Comment getById(int comment_id);

    public List<Comment> getCommentAll();
}
