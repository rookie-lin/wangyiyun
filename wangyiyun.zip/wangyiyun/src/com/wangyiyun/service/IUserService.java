package com.wangyiyun.service;

import com.wangyiyun.dao.entity.User;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/14
 * Time: 10:24
 * To change this template use File | Settings | File Templates.
 **/


public interface IUserService {
    public int save(User user);

    public boolean deleteById(int user_id);

    public List<User> listAll();

    public int update(User user);

    public int getCount(String condition);

    public Page<User> getPage(String condition, int currentPage, int pageSize);

    public User getById(int user_id);

}
