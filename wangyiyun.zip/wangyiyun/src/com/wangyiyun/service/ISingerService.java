package com.wangyiyun.service;

import com.wangyiyun.dao.entity.Singer;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/15
 * Time: 13:03
 * To change this template use File | Settings | File Templates.
 **/


public interface ISingerService {
    public int save(Singer singer);

    public int deleteById(int song_id);

    public int getCount(String condition);

    public List<Singer> listOnePageInfo(String condition, int currentPage, int pageSize);

    Page<Singer> getPage(String condition, int currentPage, int pageSize);

    public int update(Singer singer);

    public Singer getSingerById(int singer_id);

    public Singer getSingerByName(String singer_name);

    public List<Singer> getSingerAll();
}
