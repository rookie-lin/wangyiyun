package com.wangyiyun.service;

import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.utils.Page;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/10
 * Time: 21:04
 * To change this template use File | Settings | File Templates.
 **/


public interface ISongService {
    int save(Song song);

    boolean deleteById(int song_id);

    public List<Song> listAll();

    int update(Song song);

    int getCount(String condition);

    public Page<Song> getPage(String condition, int currentPage, int pageSize);

    public Song getById(int song_id);
}
