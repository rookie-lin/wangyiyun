package com.wangyiyun.test;

import com.wangyiyun.dao.ISongDao;
import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.dao.impl.SonDaoImpl;
import com.wangyiyun.service.ISongService;
import com.wangyiyun.service.impl.SongServiceImpl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/10
 * Time: 19:04
 * To change this template use File | Settings | File Templates.
 **/


public class test {
    public static void main(String[] args) {
        ISongService songService = new SongServiceImpl();
        int song = songService.getCount("");

            System.out.println(song);


        /* Song song = new Song(5,"哦哦","dsfsaf","4:20",1,"fsdf",0,0,0);
        ISongDao songDao = new SonDaoImpl();
        int s =songDao.save(song);  List<Song> i = songDao.listAll();
        for (Song s:i) {
            System.out.println(s);
        }
        System.out.println(s);*/
    /*    ISongDao songDao = new SonDaoImpl();
        Song song = new Song();
        song.setSong_Name("dfas");
        song.setSong_Time("fsd");
        song.setSong_Album("sdf");
        song.setSong_Singer(1);
        song.setSong_Path("fsdf");
        song.setSong_Picture("fsd");
        int save = songDao.save(song);
        System.out.println(save);*/
       /* List<Song> list = songDao.listOnePageInfo("哦", 1, 3);
        for (Song i:list) {
            System.out.println(i);
        }
        int count = songDao.getCount("哦");
        System.out.println(count);
    }*/

    /*
    *
    *
    function delCustomList(_this){
				layui.use(['form','laydate'], function() {
					layer.confirm('确定要删除么？', {
						btn: ['确定', '取消'] //按钮
					}, function() {
						$(_this).parent().parent().remove();
						layer.msg('删除成功', {
							icon: 1
						});
					}, function() {
						layer.msg('取消删除', {
							time: 2000 //20s后自动关闭
						});
					});
				});
			}
   
    *
    * */
    }
}
