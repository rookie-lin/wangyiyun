package com.wangyiyun.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wangyiyun.dao.entity.Comment;
import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.dao.entity.User;
import com.wangyiyun.service.ICommentService;
import com.wangyiyun.service.ISongService;
import com.wangyiyun.service.IUserService;
import com.wangyiyun.service.impl.CommentServiceImpl;
import com.wangyiyun.service.impl.SongServiceImpl;
import com.wangyiyun.service.impl.UserServiceImpl;
import com.wangyiyun.utils.Page;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/17
 * Time: 20:43
 * To change this template use File | Settings | File Templates.
 **/


@WebServlet("/manageComment")
public class ManageCommentServlet extends BaseServlet {
    ICommentService commentService = new CommentServiceImpl();
    IUserService userService = new UserServiceImpl();
    ISongService songService = new SongServiceImpl();
    public void listCommnet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String condition = request.getParameter("condition");
        if (condition==null){
            condition="";
        }
        String currentPageStr = request.getParameter("currentPage");
        if (currentPageStr==null || "".equals(currentPageStr)){
            currentPageStr = "1";
        }
        int currentPage = Integer.valueOf(currentPageStr);
        int pageSize = 2;
        int count = commentService.getCount(condition);
        // Page<Comment> commentlist = commentService.getPage(condition, 1, pageSize);
        Page<Comment> commentlist = commentService.getPage(condition, currentPage, pageSize);
        List<Comment> comments = commentlist.getList();
        List<Map> list = new ArrayList<>();
        long commentId = 0;
        String username = null;
        String song_name = null;
        long contentSongsId = 0;
        String CommentContent = null;
        long contentDzs = 0;
        Date commentDate = null;
        Map<String,Object> map1 = new HashMap<>();
        for (Comment comment:comments){
            Map<String,Object> map = new HashMap<>();
            commentId = comment.getCommentId();
            map.put("commentId",commentId);
            long contentUserId = comment.getContentUserId();
            User user = userService.getById((int) contentUserId);
            username = user.getUserName();
            map.put("username",username);

            long contentSongId = comment.getContentSongId();
            Song song = songService.getById((int) contentSongId);
            song_name = song.getSong_Name();
            map.put("song_name",song_name);

            contentSongsId = comment.getContentSongsId();
            map.put("contentSongsId",contentSongsId);

            CommentContent = comment.getCommentContent();
            map.put("CommentContent",CommentContent);

            contentDzs = comment.getContentDzs();
            map.put("contentDzs",contentDzs);

            commentDate = comment.getCommentDate();
            map.put("commentDate",commentDate);
            list.add(map);
        }


        if (comments!=null){
            HttpSession session = request.getSession();
            //  session.setAttribute("count",count);
            session.setAttribute("commentlist",commentlist);
            session.setAttribute("comments",list);
            session.setAttribute("condition",condition);
            response.sendRedirect("user_comment.jsp");

         //   request.getRequestDispatcher("user_comment.jsp").forward(request, response);

        }
    }

    public void deleteCommnet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String comm_id = request.getParameter("comm_id");
        int id = Integer.valueOf(comm_id);
        int i = commentService.deleteById(id);
        PrintWriter writer = response.getWriter();
        String contextPath = request.getContextPath();
        if (i>0){
            writer.write("<script type=\"text/javascript\">");
            writer.write("alert(\"删除成功\");");

            writer.write("window.location.href=\""+contextPath+"/manageComment?action=listCommnet\"");
            writer.write(" </script>");
        }
        else {
            writer.write("<script type=\"text/javascript\">");
            writer.write("alert(\"删除失败\");");

            writer.write("window.location.href=\""+contextPath+"/user_comment.jsp\"");
            writer.write(" </script>");
        }
    }
}
