package com.wangyiyun.servlet;

import com.wangyiyun.dao.entity.User;
import com.wangyiyun.service.IUserService;
import com.wangyiyun.service.impl.UserServiceImpl;
import com.wangyiyun.utils.Page;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/17
 * Time: 19:53
 * To change this template use File | Settings | File Templates.
 **/


@WebServlet("/manageUser")
public class ManageUserServlet extends BaseServlet {
    IUserService userService = new UserServiceImpl();
    public void listUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String condition = request.getParameter("condition");
        int pageSize = 5;
        if (condition==null || "".equals(condition)){
            condition="";
        }
        String currentPageStr = request.getParameter("currentPage");
        if (currentPageStr == null || currentPageStr.equals("")){
            currentPageStr = "1";
        }
        int currentPage = Integer.valueOf(currentPageStr);  //当前页
        Page<User> users = userService.getPage(condition, currentPage, pageSize);
        HttpSession session = request.getSession();  //获取session
        session.setAttribute("users",users);
        session.setAttribute("condition",condition);
        response.sendRedirect("user_list.jsp");
    }

    public void deleteUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        int id = Integer.valueOf(idStr);
        String realPath = this.getServletContext().getRealPath("/upload");
        User user = userService.getById(id);
        String headPortraitPath = user.getHeadPortraitPath();
        if (headPortraitPath!=null){
            File file = new File(realPath,headPortraitPath);
            file.delete();
        }
        boolean  isDelete = userService.deleteById(id);
        PrintWriter writer = response.getWriter();
        String contextPath = request.getContextPath();
        if (isDelete){
            writer.write("<script type=\"text/javascript\">");
            writer.write("alert(\"删除成功！\");");

            writer.write("window.location.href=\""+contextPath+"/ListUserServlet\"");
            writer.write(" </script>");
            /* response.sendRedirect("ListAllServlet");*/
        }else {
            writer.write("<script type=\"text/javascript\">");
            writer.write("alert(\"删除失败！\");");

            writer.write("window.location.href=\""+contextPath+"/ListUserServlet\"");
            writer.write(" </script>");
        }
    }
    public void initUpdateUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("user_id");
        int id = Integer.valueOf(idStr);
        User user = userService.getById(id);
        if (user!=null){
            HttpSession session = request.getSession();
            session.setAttribute("user",user);
            response.sendRedirect("user_update.jsp");
        }
    }
    public void addUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String user_name = null;
        String password = null;
        String sex = null;
        Date birthday = null;
        String address = null;
        String introducetion = null;
        String song_picture = null;
        boolean multipartContent = ServletFileUpload.isMultipartContent(request);
        if (multipartContent) {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload servletFileUpload = new ServletFileUpload(factory);
            try {
                List<FileItem> items = servletFileUpload.parseRequest(request);
                for (FileItem item : items) {
                    boolean formField = item.isFormField();
                    if (formField) {
                        String fieldName = item.getFieldName();
                     /*   if (fieldName.equals("user_id")){
                            String user_idStr = item.getString("utf-8");
                            user_id = Integer.valueOf(user_idStr);
                        }*/
                        if (fieldName.equals("user_name")) {
                            user_name = item.getString("utf-8");
                        }
                        if (fieldName.equals("password")) {
                            password = item.getString("utf-8");
                        }
                        if (fieldName.equals("sex")) {
                            sex = item.getString("utf-8");
                        }
                        if (fieldName.equals("birthday")) {
                            String birthdayStr = item.getString("utf-8");
                            birthday = Date.valueOf(birthdayStr);
                        }
                        if (fieldName.equals("address")) {
                            address = item.getString("utf-8");
                        }
                        if (fieldName.equals("introducetion")) {
                            introducetion = item.getString("utf-8");
                        }

                    } else {
                        String itemName = item.getName();
                        //   User user = userService.getById(user_id);
                        if (!"".equals(itemName)) {
                            String realPath = this.getServletContext().getRealPath("/upload/user_img");
                            String extendName = itemName.substring(itemName.lastIndexOf("."), itemName.length());
                            String uuid = UUID.randomUUID().toString();
                            song_picture = uuid + extendName;
                            File file2 = new File(realPath, song_picture);
                            item.write(file2);
                        }
                    }
                }
                User user = new User();
                user.setUserName(user_name);
                user.setSex(sex);
                user.setBirthday(birthday);
                user.setPassword(password);
                user.setIntroducetion(introducetion);
                user.setHeadPortraitPath(song_picture);
                user.setAddress(address);
                PrintWriter writer = response.getWriter();
                String contextPath = request.getContextPath();
                int save = userService.save(user);
                if (save>0){
                    response.sendRedirect("ListUserServlet");
                }else {
                    writer.write("<script type=\"text/javascript\">");
                    writer.write("alert(\"输入有误，请重新输入！\");");

                    writer.write("window.location.href=\""+contextPath+"/user_update.jsp\"");
                    writer.write(" </script>");
                }
            } catch (FileUploadException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
