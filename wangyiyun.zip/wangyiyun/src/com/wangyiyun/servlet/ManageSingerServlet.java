package com.wangyiyun.servlet;

import com.wangyiyun.dao.entity.Singer;
import com.wangyiyun.service.ISingerService;
import com.wangyiyun.service.impl.SingerServiceImpl;
import com.wangyiyun.utils.Page;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/17
 * Time: 20:09
 * To change this template use File | Settings | File Templates.
 **/


@WebServlet("/manageSinger")
public class ManageSingerServlet extends BaseServlet {
    ISingerService service = new SingerServiceImpl();
    public void listSinger(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String condition  = request.getParameter("condition");
        Page<Singer> singers = null;

        if (condition==null){
            condition="";
        }
        String currentPageStr = request.getParameter("currentPage");
        if (currentPageStr == null || currentPageStr.equals("")){
            currentPageStr = "1";
        }
        int pageSize = 5;
        int currentPage = Integer.valueOf(currentPageStr);
        HttpSession session = request.getSession();
        session.setAttribute("currentPage",currentPage);
        singers = service.getPage(condition , currentPage,pageSize);
        session.setAttribute("singers",singers);
        session.setAttribute("condition",condition);
        String contextPath = request.getContextPath();
        response.sendRedirect(contextPath+"/singer_list.jsp");
      //  request.getRequestDispatcher("singer_list.jsp").forward(request,response);
    }

    public void deleteSinger(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String singer_idStr = request.getParameter("singer_id");
        int singer_id = Integer.valueOf(singer_idStr);
        int i = service.deleteById(singer_id);
        PrintWriter writer = response.getWriter();
        String contextPath = request.getContextPath();
        if (i>0){
            writer.write("<script type=\"text/javascript\">");
            writer.write("alert(\"删除成功\");");

            writer.write("window.location.href=\""+contextPath+"/manageSinger?action=listSinger\"");
            writer.write(" </script>");
        }
        else {
            writer.write("<script type=\"text/javascript\">");
            writer.write("alert(\"删除失败\");");

            writer.write("window.location.href=\""+contextPath+"/singer_list.jsp\"");
            writer.write(" </script>");
        }
    }
    public void initUpdateSinger(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String singer_idStr = request.getParameter("singer_id");
        int singer_id = Integer.valueOf(singer_idStr);
        Singer singer = service.getSingerById(singer_id);
        HttpSession session = request.getSession();
        session.setAttribute("singer",singer);
        response.sendRedirect("singer_update.jsp");
    }
    public void UpdateSinger(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String singer_idStr = request.getParameter("singer_id");
        int singer_id = Integer.valueOf(singer_idStr);
        String singer_name = request.getParameter("singer_name");
        String singer_introduction = request.getParameter("singer_introduction");
        Singer singer = new Singer(singer_id,singer_name,singer_introduction);
        int update = service.update(singer);
        if (update>0){
            response.sendRedirect("manageSinger?action=listSinger");
        }
        else {
            response.sendRedirect("singer_list.jsp");
        }
    }
    public void addSinger(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String singer_name = request.getParameter("singer_name");
        String singer_introduction = request.getParameter("singer_introduction");
        Singer singer= service.getSingerByName(singer_name);
        String singerByName = singer.getSinger_name();
        PrintWriter writer = response.getWriter();
        String contextPath = request.getContextPath();
        if (singerByName==null || "".equals(singerByName)){
            singer.setSinger_name(singer_name);
            singer.setSinger_introduction(singer_introduction);
            int save = service.save(singer);
            if (save>0){
                response.sendRedirect("manageSinger?action=listSinger");
            }
        }else {
            writer.write("<script type=\"text/javascript\">");
            writer.write("alert(\"歌手已存在，请重新添加！\");");

            writer.write("window.location.href=\""+contextPath+"/singer_add.jsp\"");
            writer.write(" </script>");
        }
    }
}
