package com.wangyiyun.servlet;

import com.wangyiyun.dao.entity.Comment;
import com.wangyiyun.dao.entity.Singer;
import com.wangyiyun.dao.entity.Song;
import com.wangyiyun.service.ICommentService;
import com.wangyiyun.service.ISingerService;
import com.wangyiyun.service.ISongService;
import com.wangyiyun.service.impl.CommentServiceImpl;
import com.wangyiyun.service.impl.SingerServiceImpl;
import com.wangyiyun.service.impl.SongServiceImpl;
import com.wangyiyun.utils.Page;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.UUID;

/**
 * Created by IntelliJ IDEA.
 * User: 寒
 * Date: 2019/12/17
 * Time: 18:34
 * To change this template use File | Settings | File Templates.
 **/


@WebServlet("/manageSong")
public class ManageSongServlet extends BaseServlet {
    ISongService songService = new SongServiceImpl();
    ISingerService singerService = new SingerServiceImpl();
    ICommentService commentService = new CommentServiceImpl();
    public void listSong(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String condition  = request.getParameter("condition");
        Page<Song> songs = null;

        if (condition==null){
            condition="";
        }
        String currentPageStr = request.getParameter("currentPage");
        if (currentPageStr == null || currentPageStr.equals("")){
            currentPageStr = "1";
        }
        int pageSize = 5;
        int currentPage = Integer.valueOf(currentPageStr);
        session.setAttribute("currentPage",currentPage);
        songs = songService.getPage(condition , currentPage,pageSize);
        session.setAttribute("songs",songs);
        session.setAttribute("condition",condition);
        String contextPath = request.getContextPath();
        response.sendRedirect(contextPath+"/song_list.jsp");
    }
    public void deleteSong(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        int id =Integer.valueOf(idStr);
        Song song = songService.getById(id);
        String song_picture = song.getSong_Picture();
        String song_path = song.getSong_Path();
        String imgPath = this.getServletContext().getRealPath("/upload/song_img");
        String songPath = this.getServletContext().getRealPath("/upload/song");

        File file = null;
        if (song_picture != null){
            file = new File(imgPath,song_picture);
            file.delete();
        }
        if (song_path!=null){
            file = new File(songPath,song_path);
            file.delete();
        }
        List<Comment> commentAll = commentService.getCommentAll();
        for (Comment comment:commentAll){
            int csid=(int) comment.getContentSongId();
            int cid=(int) comment.getCommentId();
            if (id ==  csid){
                commentService.deleteById(cid);
            }
        }
        boolean isDelete = songService.deleteById(id);
        PrintWriter writer = response.getWriter();
        String contextPath = request.getContextPath();
        if (isDelete){
            response.sendRedirect(contextPath+"/manageSong?action=listSong");
        }else {
            writer.write("<script type=\"text/javascript\">");
            writer.write("alert(\"删除失败！\");");

            writer.write("window.location.href=\""+contextPath+"/song_list.jsp\"");
            writer.write(" </script>");
            /* response.sendRedirect("ListAllServlet");*/
        }
    }
    public void initAddSong(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Singer> singerAll = singerService.getSingerAll();
        HttpSession session = request.getSession();
        session.setAttribute("singerAll",singerAll);
        response.sendRedirect("song_add.jsp");
    }
    public void addSong(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Song song = new Song();
        boolean isMutil = ServletFileUpload.isMultipartContent(request);
        String song_name = null;
        int  singer = 0;
        String song_time = null;
        String song_picture =null;
        String song_path = null;
        String song_album = null;
        int song_id = 0;
        String onlyFileName = null;
        if (isMutil) {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            // String song_idStr = request.getParameter("song_id");
            // song_id  = Integer.valueOf(song_idStr);
            try {
                List<FileItem> items = upload.parseRequest(request);
                for (FileItem item : items) {
                    boolean isformField = item.isFormField();
                    String fieldName = item.getFieldName();
                    if (isformField) {
                        if (fieldName.equals("song_id")) {
                            String song_idStr = item.getString("utf-8");
                            song_id  = Integer.valueOf(song_idStr);
                        }
                        if (fieldName.equals("song_name")) {
                            song_name = item.getString("utf-8");
                        }
                        if (fieldName.equals("singer")) {
                            String singerStr = item.getString("utf-8");
                            singer = Integer.valueOf(singerStr);
                        }
                        if (fieldName.equals("song_time")) {
                            song_time = item.getString("utf-8");

                        }
                        if (fieldName.equals("song_album")) {
                            song_album = item.getString("utf-8");

                        }
                    } else {
                        String itemName = item.getName();
                        Song byId = songService.getById(song_id);
                        if (!"".equals(itemName)) {
                            if (fieldName.equals("song_picture")){
                                String upload1 = this.getServletContext().getRealPath("/upload/song_img");
                                String song_picture1 = byId.getSong_Picture();
                                if (song_picture1!=null && !"".equals(song_picture1)){
                                    File file = new File(upload1,song_picture1);
                                    file.delete();
                                }
                                String extendName = itemName.substring(itemName.lastIndexOf("."),itemName.length());
                                String uuid = UUID.randomUUID().toString();
                                onlyFileName = uuid + extendName;
                                song_picture = onlyFileName;
                                File file1 = new File(upload1,onlyFileName);
                                item.write(file1);
                            }
                            if (fieldName.equals("song_path")){
                                String upload1 = this.getServletContext().getRealPath("/upload/song");
                                String song_path1 = byId.getSong_Path();
                                if (song_path1!=null){
                                    File file = new File(upload1,song_path1);
                                    file.delete();
                                }
                                song_path = itemName;
                                File file1 = new File(upload1,song_path);
                                item.write(file1);
                            }
                        }
                    }
                }

                song.setSong_Name(song_name);
                song.setSong_Time(song_time);
                song.setSong_Album(song_album);
                song.setSong_Singer(singer);
                song.setSong_Path(song_path);
                song.setSong_Picture(song_picture);
                // song.setSong_Id(song_id);
                int save = songService.save(song);
                System.out.println(save);
                PrintWriter writer = response.getWriter();
                String contextPath = request.getContextPath();
                if (save > 0) {
                    response.sendRedirect("manageSong?action=listSong");
                }else {
                    writer.write("<script type=\"text/javascript\">");
                    writer.write("alert(\"添加失败，请重新添加！\");");

                    writer.write("window.location.href=\""+contextPath+"/song_add.jsp\"");
                    writer.write(" </script>");
                }
            } catch (FileUploadException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public void initUpdateSong(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String song_idStr = request.getParameter("song_id");
        int song_id = Integer.valueOf(song_idStr);
        Song songOne = songService.getById(song_id);

        if (songOne !=null){
            HttpSession session = request.getSession();
            session.setAttribute("songOne",songOne);

            response.sendRedirect("song_update.jsp");
        }
    }
    public void updateSong(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Song song = new Song();
        boolean isMutil = ServletFileUpload.isMultipartContent(request);
        String song_name = null;
        int  singer = 0;
        String song_time = null;
        String song_picture =null;
        String song_path = null;
        String song_album = null;
        int song_id = 0;
        String onlyFileName = null;
        if (isMutil) {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);

            try {
                List<FileItem> items = upload.parseRequest(request);
                for (FileItem item : items) {
                    boolean isformField = item.isFormField();
                    String fieldName = item.getFieldName();
                    if (isformField) {
                        if (fieldName.equals("song_id")) {
                            String song_idStr = item.getString("utf-8");
                            song_id  = Integer.valueOf(song_idStr);
                        }
                        if (fieldName.equals("song_name")) {
                            song_name = item.getString("utf-8");
                        }
                        if (fieldName.equals("singer")) {
                            String singerStr = item.getString("utf-8");
                            singer = Integer.valueOf(singerStr);
                        }
                        if (fieldName.equals("song_time")) {
                            song_time = item.getString("utf-8");

                        }
                        if (fieldName.equals("song_album")) {
                            song_album = item.getString("utf-8");

                        }
                    } else {
                        String itemName = item.getName();
                        Song byId = songService.getById(song_id);
                        if (!"".equals(itemName)) {
                            if (fieldName.equals("song_picture")){
                                String upload1 = this.getServletContext().getRealPath("/upload/song_img");
                                String song_picture1 = byId.getSong_Picture();
                                if (song_picture1!=null && !"".equals(song_picture1)){
                                    File file = new File(upload1,song_picture1);
                                    file.delete();
                                }
                                String extendName = itemName.substring(itemName.lastIndexOf("."),itemName.length());
                                String uuid = UUID.randomUUID().toString();
                                onlyFileName = uuid + extendName;
                                song_picture = onlyFileName;
                                File file1 = new File(upload1,onlyFileName);
                                item.write(file1);
                            }
                            if (fieldName.equals("song_path")){
                                String upload1 = this.getServletContext().getRealPath("/upload/song");
                                String song_path1 = byId.getSong_Path();
                                if (song_path1!=null){
                                    File file = new File(upload1,song_path1);
                                    file.delete();
                                }

                                song_path = itemName;
                                File file1 = new File(upload1,song_path);
                                item.write(file1);
                            }

                        }
                    }
                }

                song.setSong_Name(song_name);
                song.setSong_Time(song_time);
                song.setSong_Album(song_album);
                song.setSong_Singer(singer);
                song.setSong_Path(song_path);
                song.setSong_Picture(song_picture);
                song.setSong_Id(song_id);
                int save = songService.update(song);
                System.out.println(save);
                PrintWriter writer = response.getWriter();
                String contextPath = request.getContextPath();
                if (save > 0) {
                    response.sendRedirect("manageSong?action=listSong");
                } else {
                    writer.write("<script type=\"text/javascript\">");
                    writer.write("alert(\"修改失败，请重新添加！\");");

                    writer.write("window.location.href=\""+contextPath+"/song_update.jsp\"");
                    writer.write(" </script>");

                }
            } catch (FileUploadException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}

